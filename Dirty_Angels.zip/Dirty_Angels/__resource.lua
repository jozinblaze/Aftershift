resource_manifest_version '44febabe-d386-4d18-afbe-5e627f4af937'
this_is_a_map 'yes'

Author 'Igro45'

Discord_Mapping 'https://discord.gg/2bjt66Z43r'

Twitch 'https://twitch.tv/igro45'

YouTube 'https://www.youtube.com/channel/UCv-Bl3W4KJOwXnJKBqG8gTA'

Discord_Tag '✪igro45#0045'