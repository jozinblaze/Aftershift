function setUpCameraApp(url){
    $('.phone-home-container').click();
}